// This file is provided for compatibility reasons with the deprecated
// (non-Unified) Adafruit_LSM303 library. Any new development should use
// the Adafruit_L3GD20_U.h header, this file is provided to try to minimize
// issues with projects that depend on the older driver.

#ifndef __ADAFRUIT_L3GD20_H__
#define __ADAFRUIT_L3GD20_H__

#include "Adafruit_L3GD20_U.h"

#endif // __ADAFRUIT_L3GD20_H__
